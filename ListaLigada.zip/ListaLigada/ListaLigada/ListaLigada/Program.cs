﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaLigada
{
    class Program
    {
        static void Main(string[] args)
        {
            CriarListas();
        }


        //  EXERCICIO A - IMPLEMENTAÇÃO DE LISTA LIGADA
        //  PARTE 1 : CRIAÇÃO DE CLASS LISTA LIGADA
        public class ListaLigada
        {
            // variável para armezerar valor da lista
            public string[] valores;

            //Obter posição da lista
            public string this[int posicao]
            {
                get { return valores[posicao]; }
            }
            //Lista
            public string[] Lista
            {
                get { return valores; }
            }

        }


        //  EXERCICIO A - IMPLEMENTAÇÃO DE LISTA LIGADA
        //  PARTE 2 : UTILIZAÇÃO DA LISTA LIGADA

        public static void CriarListas()
        {
            // Recupera o arquivo com os dados de teste
            // EXEMPLO DOS DADOS
            // Teste 1
            // Teste 2
            // Teste 3
            string[] Arquivo = File.ReadAllLines(@"c:\entrada.txt");

            //Cria Lista1 e Lista2
            ListaLigada Lista1 = new ListaLigada();
            ListaLigada Lista2 = new ListaLigada();

            //Insere dados do arquivo na lista1
            Lista1.valores = Arquivo;

            //Armazenando na lista 2 os valores obtidos
            Lista2.valores = Lista1.valores;

            // Invertendo a ordem da lista
            Array.Reverse(Lista2.valores);

            // Cria Arquivo de Saida
            var Diretorio_salvar_ArquivoSaida = @"c:\Projetos\saida.txt";
            using (FileStream ArquivoSaida = File.Create(Diretorio_salvar_ArquivoSaida))
            {
                using (StreamWriter Escrever_ArquivoSaida = new StreamWriter(ArquivoSaida))
                {
                    foreach (var itemSaida in Lista2.Lista)
                    {
                        Escrever_ArquivoSaida.WriteLine(itemSaida);
                    }

                }
            }

        }



    }
}
